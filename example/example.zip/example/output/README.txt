MetEvolSim output files are saved in this folder.
