../build/bin/run -seed 720920 -generations 10000 -n 100 -sigma 0.01 -mu 1e-3 -w 1e-8 -alpha 0.5 -beta 0.0 -Q 2.0 -PC







