#options(show.error.messages = FALSE, warn=-1)

setwd("/Users/charlesrocabert/git/MetEvolSim/Holzhutter2004/example")

#------------------#
# 1) Load the data #
#------------------#
d1 = read.table("population/mean_s.txt", sep=" ", h=T)
d2 = read.table("population/cv_s.txt", sep=" ", h=T)

N = length(d1[,1])
M = length(d1[1,])

XRG = range(d1$g)
YRG = range(d1[,2:M])
colors = rainbow(M-1)

pdf(file="figures/0_mean_conc.pdf")
plot(x=NULL, xlim=XRG, ylim=YRG, log="xy", xlab="Generations", ylab="Mean concentration", main="Population mean concentrations")
for (i in seq(2,M))
{
	lines(d1$g, d1[,i], col=colors[i-1], lwd=2)
}
dev.off()

XRG = range(d1[,2:M])
YRG = range(d2[,2:M])
YRG[1] = max(1e-8, YRG[1])

pdf(file="figures/0_mean_vs_CV.pdf")
plot(x=NULL, xlim=XRG, ylim=YRG, log="xy", xlab="<[S]>", ylab="CV([S])", main="Population mean [S] vs. CV")
for (i in seq(1,N))
{
	points(t(d1[i,2:M]), t(d2[i,2:M]), pch=20)
}
dev.off()

