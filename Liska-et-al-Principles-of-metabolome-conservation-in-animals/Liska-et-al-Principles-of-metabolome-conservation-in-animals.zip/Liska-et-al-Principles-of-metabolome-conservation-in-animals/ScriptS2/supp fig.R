library("tidyverse")
library("cowplot")
library("reshape2")
library("ggcorrplot")
library("corrplot")
library("ppcor")
library("ggpubr")
library("forcats")

build_dataset <- function( threshold )
{
  #-------------------------#
  # 1) Load simulation data #
  #-------------------------#
  sim           = read.table("Holzhutter2004_simulations.txt", h=T, sep=" ")
  mca           = read.table("/Users/charlesrocabert/git/MetEvolSim-development/Model_analysis/MCA analysis/wild_type_MCA_scaled.txt", h=T, sep=" ")
  mca           = mca[mca$control_coef!=0,]
  data          = sim[sim$threshold==threshold,]
  metabolites   = data$species_id
  constants     = c("Glcout", "Lacex", "Phiex", "Pyrex", "PRPP")
  outliers      = read.table("Holzhutter2004_outliers.txt", sep=" ")
  metabolites   = metabolites[!(metabolites%in%constants)]
  metabolites   = metabolites[!(metabolites%in%unlist(outliers))]
  target_fluxes = c("v_9", "v_16", "v_21", "v_26")
  data          = data[data$species_id%in%metabolites,]
  #-------------------------#
  # 2) Build the dataset    #
  #-------------------------#
  Metabolite = c()
  Flux       = c()
  Abundance  = c()
  ER         = c()
  MetCC      = c()
  DosageSens = c()
  for(met in metabolites)
  {
    for(flux in target_fluxes)
    {
      Metabolite = c(Metabolite, met)
      Flux       = c(Flux, flux)
      Abundance  = c(Abundance, data[data$species_id==met,"mean_X"])
      ER         = c(ER, data[data$species_id==met,"mean_ER"])
      cc         = mca[mca$species_id==met & mca$flux_id==flux,"control_coef"]
      MetCC      = c(MetCC, cc)
      DosageSens = c(DosageSens, abs(1/cc))
    }
  }
  dataset = data.frame(Metabolite, Flux, Abundance, ER, MetCC, DosageSens)
  return(dataset)
}

##################
#      MAIN      #
##################

# Indicate here the location of the folder DataS2 on your computer.
#setwd(Path to DataS2)
setwd("/Users/charlesrocabert/git/MetEvolSim-development/Model_analysis/DataS3")

# THRESHOLDS = c(Inf, 1e-02, 1e-03, 1e-04, 1e-05)

d = build_dataset(1e-05)
d = d[order(d$Abundance),]
d$Metabolite = factor(d$Metabolite, levels=d$Metabolite)

head(d)
sum(d[d$Flux=="v_9","MetCC"])
hist(d$MetCC)
ggplot(d, aes(fct_inorder(Metabolite), log10(DosageSens))) + geom_boxplot(fill=rgb(81,149,167,max=255)) + theme_minimal() + xlab("Metabolites ordered by increasing abundance") + ylab("Dosage sensitivity for the four key fluxes") + ggtitle("Dosage sensitivity of the four key fluxes depending on metabolite abundance") + theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

cor.test(d$Abundance, log10(d$DosageSens), method="spearman")

