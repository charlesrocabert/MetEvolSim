#!/usr/bin/env Rscript

library("tidyverse")
library("cowplot")
library("reshape2")
library("ggcorrplot")
library("corrplot")
library("ppcor")
library("ggpubr")
library("MASS")


### Build the enzyme essentiality score dataset, given the drop coefficient and the dist threshold ###
build_enzyme_essentiality_score_dataset <- function( drop_coefficient, dist_threshold )
{
  #----------------------------------------#
  # 1) Load and prepare data               #
  #----------------------------------------#
  sim           = read.table("Holzhutter2004_simulations.txt", h=T, sep=" ")
  sens          = read.table("Holzhutter2004_random_sensitivity_analysis.txt", h=T, sep=" ")
  sens          = sens[2:length(sens[,1]),]
  drift         = sim[sim$threshold==Inf,]
  select        = sim[sim$threshold==1e-4,]
  metabolites   = select$species_id
  constants     = c("Glcout", "Lacex", "Phiex", "Pyrex", "PRPP")
  outliers      = read.table("Holzhutter2004_outliers.txt", sep=" ")
  metabolites   = metabolites[!(metabolites%in%constants)]
  metabolites   = metabolites[!(metabolites%in%unlist(outliers))]
  target_fluxes = c("v_9", "v_16", "v_21", "v_26")
  coupling      = cor(abs(sens[,c(metabolites,target_fluxes)]), method="spearman")
  coupling      = rowMeans(coupling[metabolites,target_fluxes])
  drift         = drift[drift$species_id%in%metabolites,]
  select        = select[select$species_id%in%metabolites,]
  #----------------------------------------#
  # 2) Build the dataset                   #
  #----------------------------------------#
  dataset = c()
  for(met in metabolites)
  {
    mean_ER_drift     = drift[drift$species_id==met,"mean_ER"]
    mean_ER_selection = select[select$species_id==met,"mean_ER"]
    sd_ER_drift       = drift[drift$species_id==met,"sd_ER"]
    sd_ER_selection   = select[select$species_id==met,"sd_ER"]
    Abundance         = drift[drift$species_id==met,"mean_X"]
    Coupling          = coupling[met][[1]]
    dataset           = rbind(dataset, c(mean_ER_drift, mean_ER_selection, sd_ER_drift, sd_ER_selection, Abundance, Coupling))
  }
  dataset        = as.data.frame(dataset)
  dataset$Name   = metabolites
  names(dataset) = c("mean_ER_drift", "mean_ER_selection", "sd_ER_drift", "sd_ER_selection", "Abundance", "Fitness_coupling", "Name")
  #----------------------------------------#
  # 3) Build the flux drop data            #
  #----------------------------------------#
  flux_drop         = read.table("Holzhutter2004_flux_drop_analysis.txt", h=T, sep=" ")
  flux_drop         = flux_drop[flux_drop$drop_value < 1.01*drop_coefficient & flux_drop$drop_value > 0.99*drop_coefficient,]
  fluxes            = unique(flux_drop$reaction)
  flux_to_met       = read.table("Holzhutter2004_reaction_to_species_map.txt", h=F, sep=" ")
  REACTION          = c()
  METABOLITE        = c()
  MOMA              = c()
  ABUNDANCE         = c()
  COUPLING          = c()
  MEAN_ER_DRIFT     = c()
  MEAN_ER_SELECTION = c()
  SD_ER_DRIFT       = c()
  SD_ER_SELECTION   = c()
  print(paste0(">>> ", unique(flux_drop$drop_value)))
  for (flux in fluxes)
  {
    reaction = flux
    moma     = flux_drop[flux_drop$reaction==reaction,"dist"]
    if (!is.na(moma))
    {
      ### Initialization ###
      Lmap = flux_to_met[flux_to_met[,1]==flux,]
      for (i in 1:length(Lmap[,1]))
      {
        pos = Lmap[i,2]
        met = Lmap[i,3]
        if (met %in% dataset$Name & !(met %in% unlist(outliers)) & !(met %in% constants))
        {
          REACTION          = c(REACTION, reaction)
          METABOLITE        = c(METABOLITE, met)
          MOMA              = c(MOMA, moma)
          ABUNDANCE         = c(ABUNDANCE, dataset[dataset$Name==met,"Abundance"])
          COUPLING          = c(COUPLING, dataset[dataset$Name==met,"Fitness_coupling"])
          MEAN_ER_DRIFT     = c(MEAN_ER_DRIFT, dataset[dataset$Name==met,"mean_ER_drift"])
          MEAN_ER_SELECTION = c(MEAN_ER_SELECTION, dataset[dataset$Name==met,"mean_ER_selection"])
          SD_ER_DRIFT       = c(SD_ER_DRIFT, dataset[dataset$Name==met,"sd_ER_drift"])
          SD_ER_SELECTION   = c(SD_ER_SELECTION, dataset[dataset$Name==met,"sd_ER_selection"])
        }
      }
    }
  }
  ess_analysis            = data.frame(MOMA, ABUNDANCE, COUPLING, MEAN_ER_DRIFT, MEAN_ER_SELECTION, SD_ER_DRIFT, SD_ER_SELECTION)
  names(ess_analysis)     = c("Dist", "Abundance", "Fitness_coupling", "mean_ER_drift", "mean_ER_selection", "sd_ER_drift", "sd_ER_selection")
  ess_analysis$Reaction   = REACTION
  ess_analysis$Metabolite = METABOLITE
  ess_analysis$Drop_coef  = rep(drop_coefficient, length(ess_analysis[,1]))
  ess_analysis$Dist[ess_analysis$Dist < dist_threshold]  = 0
  ess_analysis$Dist[ess_analysis$Dist >= dist_threshold] = 1
  #----------------------------------------#
  # 4) Re-organize the data per metabolite #
  #----------------------------------------#
  res            = as.data.frame.matrix(table(ess_analysis$Metabolite, ess_analysis$Dist))
  res$Metabolite = rownames(res)
  rownames(res)  = c()
  res            = res[,c(3,2)]
  names(res)     = c("Metabolite", "Essential")
  res$Essential[res$Essential>0] = 1
  res$Essential = as.factor(res$Essential)
  Abundance     = c()
  ER_selection  = c()
  ER_drift      = c()
  for(met in res$Metabolite)
  {
    Abundance    = c(Abundance, select[select$species_id==met,"mean_X"])
    ER_selection = c(ER_selection, select[select$species_id==met,"mean_ER"])
    ER_drift     = c(ER_drift, drift[drift$species_id==met,"mean_ER"])
  }
  res$Abundance    = Abundance
  res$ER_selection = ER_selection
  res$ER_drift     = ER_drift
  return(res)
}

### Plot the abundance/ER figure  ###
plot_abund_ER <- function( D, title, y_range, stat_line_x, stat_line_y )
{
  cort      = cor.test(D$mean_X, D$mean_ER, method="spearman")
  cor_pval  = formatC(cort$p.value, format="e", digits=2)
  cor_rho   = round(cort$estimate[[1]],2)
  stat_line = paste("Spearman ρ = ", cor_rho, "\n(p-value = ", cor_pval, ")", sep="")
  p = ggplot(D, aes(x=mean_X, y=mean_ER)) +
    geom_smooth(color="#3497a9", fill="#3497a9", span=0.9) +
    geom_point() +
    geom_errorbar(aes(ymin=mean_ER-sd_ER, ymax=mean_ER+sd_ER), width=.2) +
    annotate(geom="text", x=stat_line_x, y=stat_line_y, label=stat_line, hjust=0, size=3.5) +
    ylim(y_range[1], y_range[2]) +
    xlab("Metabolite abundance (log-scale)") +
    ylab("Evolutionary rate\n(log-scale)") +
    ggtitle(title) +
    theme_minimal()
  return(p)
}

### Plot the Essentiality Score/ER figure  ###
plot_ES_ER <- function( D, title, y_range, selection )
{
  my_comp = list(c("0", "1"))
  my_samp = table(D$Essential)
  my_samp = as.data.frame(cbind(c("0","1"),c(my_samp[[1]],my_samp[[2]])))
  names(my_samp) = c("Essential", "n")
  if (selection == "Selection")
  {
    p = ggplot(D, aes(Essential, ER_selection, group=Essential)) +
      geom_boxplot(fill=rgb(81,149,167,max=255)) +
      geom_jitter(width=0.2) +
      xlab("") +
      ylab("Mean evolutionary rate\n(log-scale)") +
      ggtitle("Stabilizing selection") +
      scale_x_discrete(labels=c("Non essential\nreaction","Essential\nreaction")) +
      scale_y_continuous(expand=expansion()) +
      geom_text(data=my_samp, aes(label = sprintf('n = %s', n), y=-4), vjust=1.5) +
      stat_compare_means(comparisons=my_comp, method="wilcox.test", vjust=-0.5) +
      ylim(y_range[1], y_range[2]+1.5) +
      theme_minimal() +
      theme(axis.text=element_text(size=10))
    return(p)
  }
  if (selection == "Drift")
  {
    p = ggplot(D, aes(Essential, ER_drift, group=Essential)) +
      geom_boxplot(fill=rgb(81,149,167,max=255)) +
      geom_jitter(width=0.2) +
      xlab("") +
      ylab("Mean evolutionary rate\n(log-scale)") +
      ggtitle("Genetic drift") +
      scale_x_discrete(labels=c("Non essential\nreaction","Essential\nreaction")) +
      #scale_y_continuous(expand=expansion()) +
      geom_text(data=my_samp, aes(label = sprintf('n = %s', n), y=-3.5), vjust=1.5) +
      stat_compare_means(comparisons=my_comp, method="wilcox.test", vjust=-0.5) +
      ylim(y_range[1], y_range[2]+1.5) +
      theme_minimal() +
      theme(axis.text=element_text(size=10))
    return(p)
  }
}

### Plot the fitness coupling ###
plot_fitness_coupling <- function( D )
{
  reg         = lm(D$Fitness_coupling~D$Abundance)
  cort        = cor.test(D$Abundance, D$Fitness_coupling, method="spearman")
  reg_pval    = formatC(summary(reg)$coefficients[2,4], format="e", digits=2)
  reg_rsquare = round(summary(reg)$r.squared,2)
  cor_pval    = formatC(cort$p.value, format="e", digits=2)
  cor_rho     = round(cort$estimate[[1]],2)
  stat_line   = paste("Spearman ρ = ", cor_rho, "\n(p-value = ", cor_pval, ")", sep="")
  p = ggplot(D, aes(x=Abundance, y=Fitness_coupling)) +
    geom_smooth(color="tan1", fill="tan1", span=0.9) +
    geom_point() +
    annotate(geom="text", x=-5, y=0.43, label=stat_line, hjust=0, size=3.5) +
    xlab("Metabolite abundance (log-scale)") +
    ylab("Fitness coupling") +
    ggtitle("Metabolite fitness coupling") +
    theme_minimal()
  return(p)
}

### Plot the correlation matrix ###
plot_correlation_matrix <- function( C, pC )
{
  p = ggcorrplot(as.matrix(C[,2]), lab=T, p.mat=as.matrix(pC[,2]), sig.level=0.05, insig="pch", pch.cex=15, pch.col="tomato", colors=c("#3497a9", "white", "tan1"), legend.title="Spearman\ncorrelation") +
    theme(panel.grid=element_blank(), axis.text.y=element_blank()) +
    ggtitle("    Metabolite fitness coupling\n    correlation with:")
  # p = ggcorrplot(as.matrix(C), lab=T, p.mat=as.matrix(pC), sig.level=0.05, insig="pch", pch.cex=15, pch.col="tomato", colors=c("#6D9EC1", "white", "orange"), legend.title="Spearman\ncorrelation") +
  #   ggtitle("Metabolite fitness coupling\ncorrelation with:")
  # return(p)
}


##################
#      MAIN      #
##################

# Indicate here the location of the folder DataS3 on your computer.
#setwd(Path to DataS3)
setwd("/Users/charlesrocabert/git/MetEvolSim-development/Model_analysis/DataS3")
#-----------------------------#
# 1) Load simulation data     #
#-----------------------------#
sim           = read.table("Holzhutter2004_simulations.txt", h=T, sep=" ")
sens          = read.table("Holzhutter2004_random_sensitivity_analysis.txt", h=T, sep=" ")
sens          = sens[2:length(sens[,1]),]
drift         = sim[sim$threshold==Inf,]
select        = sim[sim$threshold==1e-4,]
metabolites   = select$species_id
constants     = c("Glcout", "Lacex", "Phiex", "Pyrex", "PRPP")
outliers      = read.table("Holzhutter2004_outliers.txt", sep=" ")
metabolites   = metabolites[!(metabolites%in%constants)]
metabolites   = metabolites[!(metabolites%in%unlist(outliers))]
target_fluxes = c("v_9", "v_16", "v_21", "v_26")
coupling      = cor(abs(sens[,c(metabolites,target_fluxes)]), method="spearman")
coupling      = rowMeans(coupling[metabolites,target_fluxes])
drift         = drift[drift$species_id%in%metabolites,]
select        = select[select$species_id%in%metabolites,]
y_range1      = range(c(drift$mean_ER-drift$sd_ER, drift$mean_ER+drift$sd_ER, select$mean_ER-select$sd_ER, select$mean_ER+select$sd_ER))
y_range1[2]   = y_range1[2]+0.9

#-----------------------------#
# 2) Build the dataset        #
#-----------------------------#
dataset1 = c()
for(met in metabolites)
{
  ER_drift     = drift[drift$species_id==met,"mean_ER"]
  ER_selection = select[select$species_id==met,"mean_ER"]
  Abundance    = drift[drift$species_id==met,"mean_X"]
  Coupling     = coupling[met][[1]]
  dataset1     = rbind(dataset1, c(ER_drift, ER_selection, Abundance, Coupling))
}
dataset1        = as.data.frame(dataset1)
names(dataset1) = c("ER_drift", "ER_selection", "Abundance", "Fitness_coupling")
C               = cor(dataset1, method="spearman")
pC              = cor_pmat(dataset1, method="spearman")
C               = C[c(2,1), c(3,4)]
pC              = pC[c(2,1), c(3,4)]
rownames(C)     = c("ER under\nselection", "ER under\ngenetic drift")
colnames(C)     = c("Metabolite\nabundance", "Fitness\ncoupling")
rownames(pC)    = c("ER under\nselection", "ER under\ngenetic drift")
colnames(pC)    = c("Metabolite\nabundance", "Fitness\ncoupling")

#-----------------------------#
# 3) Build the flux drop data #
#-----------------------------#
flux_drop         = read.table("Holzhutter2004_flux_drop_analysis.txt", h=T, sep=" ")
drop_coefficients = unique(flux_drop$drop_value)
dataset2          = build_enzyme_essentiality_score_dataset(1e-5, 1.1)
y_range2          = c(-13, -4)

#-----------------------------#
# 4) Create the figure        #
#-----------------------------#
p1 = plot_abund_ER(select, "Stabilizing selection", y_range1, -5.5, -12)
p2 = plot_abund_ER(drift, "Genetic drift", y_range1, -5.5, -12)
p3 = plot_ES_ER(dataset2, "Stabilizing selection", y_range2, "Selection")
p4 = plot_ES_ER(dataset2, "Genetic drift", y_range2, "Drift")
p5 = plot_fitness_coupling(dataset1)
p6 = plot_correlation_matrix(C, pC)

plot_grid(p1, p2, p3, p4, p5, p6, ncol=2, labels="AUTO")

#-----------------------------#
# 5) Additional analyses      #
#-----------------------------#
wilcox.test(dataset2[dataset2$Essential==0,"ER_selection"],dataset2[dataset2$Essential==1,"ER_selection"])
wilcox.test(dataset2[dataset2$Essential==0,"ER_drift"],dataset2[dataset2$Essential==1,"ER_drift"])
length(dataset2$ER_selection)
model = lm(ER_selection ~ Essential+Abundance, data=dataset2)
summary(model)

