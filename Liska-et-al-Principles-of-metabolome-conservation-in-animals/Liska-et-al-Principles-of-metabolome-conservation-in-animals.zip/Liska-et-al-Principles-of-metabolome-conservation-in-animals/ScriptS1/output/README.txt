Output files are saved in this folder.
