<p align="center">
    Modelling supplementary material for Liska et al. manuscript "Principles of metabolome conservation in animals".
    <br/><br/>
</p>

-----------------

You can download the material here : https://github.com/charlesrocabert/MetEvolSim-development/raw/master/Liska-et-al-Principles-of-metabolome-conservation-in-animals/Liska-et-al-Principles-of-metabolome-conservation-in-animals.zip
